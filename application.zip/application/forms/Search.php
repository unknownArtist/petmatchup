<?php

class Application_Form_Search extends Zend_Form
{

    public function init()
    {
       $profileT =  array(
            'For mating'  =>  'For mating',
            'For sale'    =>  'For sale',
            'Adoption'    =>  'Adoption',
            'Showcase'    =>  'Showcase'
       );
       
       $Sex     = array(
             'All'   =>  'All',
             'Dog'   =>  'Dog',
             'Cat'   =>  'Cat',
             'Other' =>  'Other'
        );
       
       $MaleOrFemal = array(
            'Male'     =>  'Male',
            'Female'   =>  'Female',
            
        );
       
       $selectCountry = array( 
            0   =>  '',
            'America'   =>  'America'
            
            );
       
       
       $statesofamerica = Zend_Registry::get('states');
        
 
        
        //////////////////////////////////////////////////////////////////
        
        $this->setMethod('post');
        $this->setAction('search/search-Profile');
        
        $profileType = new Zend_Form_Element_Select('profileType');
                         $profileType->setLabel('Profile Type')
                                     ->setRequired(true)
                                     ->addFilter('StripTags')
                                     ->addFilter('StringTrim')
                                     ->addMultiOptions($profileT);
                         
        $sex        = new Zend_Form_Element_Select('sex');
        $sex->setLabel('Search For')
                       ->addFilter('StripTags')
                        ->addFilter('StringTrim')
                        ->addValidator('NotEmpty')
                       ->addMultiOptions($Sex);
        
        $race        = new Zend_Form_Element_Text('race');
        $race->setLabel('Race')
                        ->addFilter('StripTags')
                        ->addFilter('StringTrim')
                        ->addValidator('NotEmpty');
        
        $maleORFemale        = new Zend_Form_Element_Select('kind');
        $maleORFemale->setLabel('Kind')
                      ->addFilter('StripTags')
                      ->addFilter('StringTrim')
                      ->addValidator('NotEmpty')
                      ->addMultiOptions($MaleOrFemal);
        
        $Country        = new Zend_Form_Element_Select('Country');
        $Country->setLabel('Select Country')
                       ->addFilter('StripTags')
                        ->addFilter('StringTrim')
                        ->addValidator('NotEmpty')
                        ->addMultiOptions($selectCountry);
        $state        = new Zend_Form_Element_Select('states');
        $state->setLabel('Select State')
                        ->addFilter('StripTags')
                        ->addFilter('StringTrim')
                        ->addValidator('NotEmpty')
                        ->addMultiOptions($statesofamerica);
        $zip = new Zend_Form_Element_Text('zip');
        $zip->setLabel('Zip')
                       ->addFilter('StripTags')
                       ->addFilter('StringTrim')
                       ->addValidator('NotEmpty');
        
        
         $submit = new Zend_Form_Element_Submit('submit');
                         
        $this->addElements(array(
            
            $profileType,
            $sex,
            $race,
            $maleORFemale,
            $Country,
            $state,
            $zip,
            $submit
        ));
        
    }


}

