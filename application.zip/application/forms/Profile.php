<?php

class Application_Form_Profile extends Zend_Form
{

    public function init()
    {
        
   //     parent::__construct($options);
  	// setting Form name,Form action and Form Ecryption type
	$this->setName('document');
//	$this->setAction("");
	$this->setAttrib('enctype', 'multipart/form-data');
        
        
        
        $selectCountry = array( 
            0   =>  '',
            'America'   =>  'America'
            
            );
        $selectState = array( 
            0   =>  '',
            1   =>  'Alabama'
            
            );
        $Kindof = array(
            'Male'   =>  'Male',
            'Female'   =>  'Female',
            
        );
        
       $Sex     = array(
             'Dog'   =>  'Dog',
             'Cat'   =>  'Cat',
             'Other'  =>  'Other'
        );
       
       $profileType = array(
            'For mating'   =>  'For mating',
            'For sale'   =>  'For sale',
            'Adoption'   =>  'Adoption',
            'Showcase'   =>  'Showcase'
       );
       
       $nego    = array(
           
            'Yes'   =>  'Yes',
            'No'   =>  'No',
       );
       
       $Selectpurebred = array(
           
            'Yes'   =>  'Yes',
            'No'    =>  'No'
       );
       
       $Selecthavepapers = array(
           
          'yes'   =>  'Yes',
          'No'    =>  'No'
       );
       $statesofamerica = Zend_Registry::get('states');
        
/////////////////////////////////////////////////////////////////////////////////  
       ///////////////////////////////////////////////////////////////
        
        
        $this->setMethod('post');
        $this->setAction('/profile/addprofile');
        
        $Accessiblename = new Zend_Form_Element_Text('Accessible_name');
        $Accessiblename->setLabel('Accessible name')
                        ->setRequired(true)
                        ->addFilter('StripTags')
                        ->addFilter('StringTrim')
                        ->addValidator('NotEmpty');
        
        $Country        = new Zend_Form_Element_Select('Country');
        $Country->setLabel('Select Country')
                       ->addFilter('StripTags')
                        ->addFilter('StringTrim')
                        ->addValidator('NotEmpty')
                       ->addMultiOptions($selectCountry);
        
        
        $state        = new Zend_Form_Element_Select('states');
        $state->setLabel('Select State')
                        ->addFilter('StripTags')
                        ->addFilter('StringTrim')
                        ->addValidator('NotEmpty')
                        ->addMultiOptions($statesofamerica);
        
        $city = new Zend_Form_Element_Text('city');
        $city->setLabel('City')
                       ->addFilter('StripTags')
                        ->addFilter('StringTrim')
                        ->addValidator('NotEmpty');
        
        $zip = new Zend_Form_Element_Text('zip');
        $zip->setLabel('Zip')
                       ->addFilter('StripTags')
                        ->addFilter('StringTrim')
                        ->addValidator('NotEmpty');
        
        $kind        = new Zend_Form_Element_Select('kind');
        $kind->setLabel('Kind')
                       ->addFilter('StripTags')
                        ->addFilter('StringTrim')
                        ->addValidator('NotEmpty')
                       ->addMultiOptions($Kindof);
        
        $race        = new Zend_Form_Element_Text('race');
        $race->setLabel('Race')
                        ->addFilter('StripTags')
                        ->addFilter('StringTrim')
                        ->addValidator('NotEmpty');
                       
        
        $sex        = new Zend_Form_Element_Select('sex');
        $sex->setLabel('Sex')
                       ->addFilter('StripTags')
                        ->addFilter('StringTrim')
                        ->addValidator('NotEmpty')
                       ->addMultiOptions($Sex);
        
        $purebred   = new Zend_Form_Element_Select('pure_bred');
        $purebred->setLabel('Pure bred')
                 ->addFilter('StripTags')
                 ->addFilter('StringTrim')
                 ->addValidator('NotEmpty')
                 ->addMultiOptions($Selectpurebred);
                 
                 
        
        $havepapers   = new Zend_Form_Element_Select('have_papers');
        $havepapers->setLabel('Have papers')
                   ->addFilter('StripTags')
                        ->addFilter('StringTrim')
                        ->addValidator('NotEmpty')
                   ->addMultiOptions($Selecthavepapers);
                   
        
        $profiletype        = new Zend_Form_Element_Select('profile_type');
        $profiletype->setLabel('Profile Type')
                       ->addFilter('StripTags')
                        ->addFilter('StringTrim')
                        ->addValidator('NotEmpty')
                       ->addMultiOptions($profileType);
        
        $Amount = new Zend_Form_Element_Text('Amount');
        $Amount->setLabel('Amount')
                       ->addFilter('StripTags')
                        ->addFilter('StringTrim')
                        ->addValidator('NotEmpty');
        
        $Negotiable        = new Zend_Form_Element_Select('Negotiable');
        $Negotiable->setLabel('Negotiable')
                       ->addFilter('StripTags')
                       ->addFilter('StringTrim')
                       ->addValidator('NotEmpty')
                       ->addMultiOptions($nego);
        
        $picupload        = new Zend_Form_Element_File('pic_upload_path');
        //$picupload->setLabel('Choose File');
                  
		  $picupload->setLabel('Document File Path')
				  ->setRequired(true);
        
        
        
        $description      = new Zend_Form_Element_Textarea('description');
        $description->setLabel('Description')
                        ->addFilter('StripTags')
                        ->addFilter('StringTrim')
                        ->addValidator('NotEmpty');
        
        $email        = new Zend_Form_Element_Text('email');
        $email->setLabel('Email')
                       ->addFilter('StripTags')
                        ->addFilter('StringTrim')
                        ->addValidator('NotEmpty');
        
        $phone        = new Zend_Form_Element_Text('phone');
        $phone->setLabel('Phone')
                        ->addFilter('StripTags')
                        ->addFilter('StringTrim')
                        ->addValidator('NotEmpty');
        
        
        $submit = new Zend_Form_Element_Submit('submit');
        
        
        
        
                 
        
        
        
        
        $this->addElements(array(
            
            $Accessiblename,
            $Country,
            $state,
            $city,
            $kind,
            $sex,
            $race,
            $purebred,
            $havepapers,
            $profiletype,
            $Amount,
            $Negotiable,
            $picupload,
           // $image,
            $description,
            $email,
            $phone,
                        
            $submit
        ));
        
        
    }


}

