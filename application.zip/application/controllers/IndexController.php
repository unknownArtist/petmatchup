<?php

class IndexController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
       
        
        $form = new Application_Form_SignIn();
        $this->view->SignIn = $form;
        
         $authAdapter = $this->getAuthAdapter();
        
        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                $email = $form->getValue('email');
                $password = $form->getValue('password');
                $authAdapter->setIdentity($email)
                    ->setCredential($password);
                
             $auth = Zend_Auth::getInstance();
        
             $result = $auth->authenticate($authAdapter);
        
             if($result->isValid())
                {
                    echo '<h1>'."valid username".'</h1>';
                }
               else
            {
                $form->populate($formData);
                echo '<h1>'."Invalid username".'</h1>';
            }
                
            } 
            else
            {
                $form->populate($formData);
            }
        
        
        
        
         }
    }

   

    public function loginAction()
    {
       
    }

    public function logoutAction()
    {
        // action body
    }
    
    private function getAuthAdapter()
    {
        $auth = new Zend_Auth_Adapter_DbTable(Zend_Db_Table::getDefaultAdapter());
        $auth->setTableName('signup')
             ->setIdentityColumn('Email')
             ->setCredentialColumn('password');
        
        return $auth;
    }


}







