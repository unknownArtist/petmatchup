<?php

class SearchController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
        
        
        $SearchForm = new Application_Form_Search();
        
        $this->view->form = $SearchForm;
        
        
    }

    public function searchProfileAction()
    {
        
        $AppliedSearch = new Application_Model_Profile();
          
          $pType    = $_POST['profileType'];
          $sex      = $_POST['sex'];
          $race     = $_POST['race'];
          $kind     = $_POST['kind'];
          $Country  = $_POST['Country'];
          $states   = $_POST['states'];
          $zip      = $_POST['zip'];
          
        
          
          
          $where = "profile_type LIKE   '%$pType%'
                    AND sex  LIKE       '%$sex%'
                    OR race LIKE        '%$race%'
                    AND kind LIKE       '%$kind%'
                    AND Country LIKE    '%$Country%'
                    OR states LIKE      '%$states%'
                    OR zip LIKE         '%$zip%'";
       
        
        $result = $AppliedSearch->fetchAll($where);
        
        foreach($result as $dd):
            echo $dd->id. "<br />";
            echo $dd->Accessible_name. "<br /> ";
            echo $dd->city. "<br />";
            echo $dd->kind."<br />";
            echo $dd->states."<br />";
        endforeach;
        die();
        $this->view->searchResult = $result;
    }


}



