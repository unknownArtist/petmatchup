<?php

class ProfileController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
        $form = new Application_Form_Profile();
        
        $this->view->form = $form;
    }

    public function addprofileAction()
    {
        
                      $form = new Application_Form_Profile();
                // $this->view->form = $form;

                 if ($this->getRequest()->isPost()) {

                 $formData = $this->getRequest()->getPost();
                 if ($form->isValid($formData)) {

                 /* Uploading Document File on Server */
                 $upload = new Zend_File_Transfer_Adapter_Http();
                 
                 $upload->setDestination(APPLICATION_PATH. "/../public/images/");
                 try {
                 // upload received file(s)
                 $upload->receive();
                 } catch (Zend_File_Transfer_Exception $e) {
                 $e->getMessage();
                 }

                 // so, Finally lets See the Data that we received on Form Submit
                 $uploadedData = $form->getValues();
                 Zend_Debug::dump($uploadedData, 'Form Data:');

                 // you MUST use following functions for knowing about uploaded file
                 # Returns the file name for 'doc_path' named file element
                 $name = $upload->getFileName('doc_path');

                 # Returns the size for 'doc_path' named file element
                 # Switches of the SI notation to return plain numbers
                 $upload->setOption(array('useByteString' => false));
                 $size = $upload->getFileSize('doc_path');

                 # Returns the mimetype for the 'doc_path' form element
                 $mimeType = $upload->getMimeType('doc_path');

                 // following lines are just for being sure that we got data
                 print "Name of uploaded file: $name
                ";
                 print "File Size: $size
                ";
                 print "File's Mime Type: $mimeType";


                 // Rename uploaded file using Zend Framework
                

                 exit;
                 } 

                 } else {

                 // this line will be called if data was not submited
                 $form->populate($formData);
                 }
                
        }
       
                
                
        
        
    


}



