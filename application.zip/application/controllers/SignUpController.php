<?php

class SignUpController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
        
        $form = new Application_Form_SignUp();
        
        $this->view->form = $form;
        
        if ($this->getRequest()->isPost())
            {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) 
                {
            
                 $data = array(
                 'firstname'            => $form->getValue('FirstName'),
                 'lastname'             => $form->getValue('LastName'),
                 'Email'                => $form->getValue('Email'),
                 'Password'             => $form->getValue('Password'),
                 'FriendsEmailAddress'  => $form->getValue('FriendsEmailAddress')
                 );
                
                $emailAddress = $form->getValue('Email');
                $CheckEmail = new Application_Model_SignUp();
                $where = "Email = '$emailAddress'";
                $temp = $CheckEmail->fetchAll($where)->count();
                if($temp > 0)
                {
                   $this->view->errorMsg = "This email is already registered";
                   $form->populate($formData);
                  
                   
                }else
                {
         
                      $signupDB = new Application_Model_SignUp();
                     if($signupDB->insert($data))
                     {
                      $this->view->message = "your ID has been created. Plz activate you account <br /> an email is sent at " .
                      $form->getValue('FriendsEmailAddress');
                      $this->view->signin = "Sign in";
                      $email = $form->getValue('Email');
                      $form->reset();

                      $this->mailToContactAction($email);
                     }

                     // $this->_redirect('index');
                             else
                                 {
                                    $form->populate($formData);
                                 }
                }
              }
            }
        
            
    }

    public function mailToContactAction($email)
    {
       
       $pass =  $this->randGenAction();
       
       //////////////////////////////////////////////////
       $smtpConfigs = array(
            
            'auth'          =>      'login',
            'username'      =>      'nayatelorg',
            'password'      =>      'quickbrown123',
            'ssl'           =>      'ssl',
            'port'          =>       465
            
        );
        
        $smtpTransportObject = new Zend_Mail_Transport_Smtp('smtp.gmail.com', $smtpConfigs);
        
        $mail = new Zend_Mail();
  
        $form = new Application_Form_ContactUS();
  
 
        $mail->addTo("letstalk_me2003@yahoo.com","john evans")
             ->setFrom('nayatelorg@gmail.com', "nayatel")
             ->setSubject('its a test email')
             ->setBodyText('your pin code is '.$pass)
             ->send($smtpTransportObject);
        
           
           
          
       
       //////////////////////////////////////////////////
       
       
    }

    public function randGenAction()
    {
       $length=15;
       $strength=0;
       
        $vowels = 'aeuy';
	$consonants = 'bdghjmnpqrstvz';
	if ($strength & 1) {
		$consonants .= 'BDGHJLMNPQRSTVWXZ';
	}
	if ($strength & 2) {
		$vowels .= "AEUY";
	}
	if ($strength & 4) {
		$consonants .= '23456789';
	}
	if ($strength & 8) {
		$consonants .= '@#$%';
	}
 
	$password = '';
	$alt = time() % 2;
	for ($i = 0; $i < $length; $i++) {
		if ($alt == 1) {
			$password .= $consonants[(rand() % strlen($consonants))];
			$alt = 0;
		} else {
			$password .= $vowels[(rand() % strlen($vowels))];
			$alt = 1;
		}
	}
	return $password;
    }


}


