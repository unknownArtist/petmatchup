<?php

class Application_Model_UserPics extends Zend_Db_Table_Abstract
{
    
    protected $_name 		= 'profile_pictures';
    protected $_primary 	= 'id';

}

