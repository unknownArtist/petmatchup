<?php

class Application_Model_Zipcode extends Zend_Db_Table_Abstract
{
	protected $_name = 'zip_code';
	protected $_primary   = 'id';

}

