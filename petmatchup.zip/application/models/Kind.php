<?php

class Application_Model_Kind extends Zend_Db_Table_Abstract
{
	protected $_name  	=	 'kinds';
	protected $_primary	=	 'id';  

}

