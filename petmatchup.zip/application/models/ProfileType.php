<?php

class Application_Model_ProfileType extends Zend_Db_Table_Abstract
{
		protected $_name 	= "profile_types";
		protected $_primary = "id";

}

