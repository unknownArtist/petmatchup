<?php

class Application_Model_State extends Zend_Db_Table_Abstract
{
	protected $_name = 'state';
	protected $_primary   = 'state_id';

}

